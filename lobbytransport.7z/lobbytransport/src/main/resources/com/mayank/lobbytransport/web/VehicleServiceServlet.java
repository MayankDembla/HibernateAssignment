package com.mayank.lobbytransport.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mayank.lobbytransport.model.VehicleBuilder;
import com.mayank.lobbytransport.service.VehicleServices;
import com.mayank.lobbytransport.service.VehicleServicesImpl;

@WebServlet("/vehicle-service")
public class VehicleServiceServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	VehicleServices service;

	public VehicleServiceServlet() {
		service = new VehicleServicesImpl();
	}

	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		String act = req.getParameter("ACT");

		switch (act) {
		
		case "regV":
			
			VehicleBuilder builder  = new VehicleBuilder(req.getParameter("VehicleNo")) ; 
			
			      builder.vehicleName(req.getParameter("VehicleName"))
			             .fueltype(req.getParameter("Fty`pe"))
			             .avergae(Float.valueOf(req.getParameter("Average")))
			             .cost(Integer.parseInt(req.getParameter("Cost")))
			             .rskm(Integer.parseInt(req.getParameter("Rs")))
			             .vehicleType(req.getParameter("Vtype"))
			             .make(req.getParameter("Make"))
			             .iCompany(req.getParameter("InsurerName"))
			             .iName(req.getParameter("CompanyName"))
			             .iDateoi(req.getParameter("Doi"))
			             .iDateoe(req.getParameter("Doe")) ;
			
			 service.registerNewVehicle(builder.build());
		}

	}

}
