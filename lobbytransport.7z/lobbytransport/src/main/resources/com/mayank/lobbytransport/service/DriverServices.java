package com.mayank.lobbytransport.service;

import java.util.List;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Driver;

public interface DriverServices {
	
	  void registerDriver(Company company) ; 
	  
	  Driver getDriverByName(String name) ; 
	  
	  List<Driver> getDrivers() ; 

}
