package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Consigner;
import com.mayank.lobbytransport.util.HibernateUtil;

public class ConsignorDaoImpl implements ConsignerDao {

	private Session session;

	public ConsignorDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
	}
	
	@Override
	public Consigner getConsigner(String name) {
		Consigner consigner = null;

		Criteria criteria = session.createCriteria(Company.class);
		criteria.add(Restrictions.eq("name", name)); // Since Company Name is Unique

		List<Consigner> listuser = criteria.list();

		if (!listuser.isEmpty())
			consigner = listuser.get(0);

		return consigner;
	}

	@Override
	public List<Consigner> getregisteredConsignor() {
		
		return session.createCriteria(Consigner.class).list();
	}

}
