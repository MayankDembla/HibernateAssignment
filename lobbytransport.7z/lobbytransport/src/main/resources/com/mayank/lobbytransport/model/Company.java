package com.mayank.lobbytransport.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Company  implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id ; 	
	
	@Column(unique = true)
	private String name;

	private String password;

	private String address;

	public List<Consigner> getConsigner() {
		return consigner;
	}

	public void setConsigner(List<Consigner> consigner) {
		this.consigner = consigner;
	}

	public List<Consignee> getConsignee() {
		return consignee;
	}

	public void setConsignee(List<Consignee> consignee) {
		this.consignee = consignee;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String city;

	private String state;

	private long mobileNumber;

	private String email;
	
	@ManyToMany
	private List<Consigner> consigner  ; 
	
	@ManyToMany
	private List<Consignee> consignee ; 
	
	Company()
	{
		// Used by internal Hibernate Api as a Bean
	}
	
	Company(CompanyBuilder builder){
		this.name = builder.name ; 
		this.password = builder.password ;
		this.address = builder.address ; 
		this.city = builder.city ; 
		this.state = builder.state ; 
		this.mobileNumber = builder.mobileNumber ; 
		this.email = builder.email ; 
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", password=" + password + ", address=" + address + ", city=" + city + ", state="
				+ state + ", mobileNumber=" + mobileNumber + ", email=" + email + "]";
	}

}
