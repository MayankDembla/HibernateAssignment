package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Driver;

public interface DriverDao {
	
	Driver getDriverByName(String name) ; 
	
	List<Driver> getregisteredDrivers() ; 

}
