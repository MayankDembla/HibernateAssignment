package com.mayank.lobbytransport.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Consigner {

	@Id
	private int consignerId;

	private String password;

	private long mobileNumber;

	// One Consigner has Many Goods
	@OneToMany(mappedBy = "consigner")
	private List<Goods> availablegoods;

	// Many Consignor has many Consignee
	@ManyToMany
	private List<Consignee> listconsignee;

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public List<Consignee> getListconsignee() {
		return listconsignee;
	}

	public void setListconsignee(List<Consignee> listconsignee) {
		this.listconsignee = listconsignee;
	}

	public List<Company> getCompany() {
		return company;
	}

	public void setCompany(List<Company> company) {
		this.company = company;
	}

	@ManyToMany(mappedBy = "consigner")
	private List<Company> company;

	public int getConsignerId() {
		return consignerId;
	}

	public void setConsignerId(int consignerId) {
		this.consignerId = consignerId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Goods> getAvailablegoods() {
		return availablegoods;
	}

	public void setAvailablegoods(List<Goods> availablegoods) {
		this.availablegoods = availablegoods;
	}

}
