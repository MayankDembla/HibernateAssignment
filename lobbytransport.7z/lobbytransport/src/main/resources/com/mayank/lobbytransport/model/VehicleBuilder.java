package com.mayank.lobbytransport.model;

public class VehicleBuilder {

	protected String vehicleNo;
	protected String name;
	protected String make;
	protected String fueltype;
	protected int rskm;
	protected float average;
	protected int cost;
	protected String vehicleType;
	
	protected String insuranceName ; 
	protected String icompanyName ; 
	protected String idateOfInsurance ; 
	protected String idateOfExpiry ; 
	
	protected String driverName ; 

	public VehicleBuilder(String vehicleNo)
	{
		this.vehicleNo = vehicleNo ;
	}
   
    public VehicleBuilder vehicleName(String name)
    {
    	this.name = name ; 
    	return this ; 
    }
    
    public VehicleBuilder make(String make)
    {
    	this.make = make ; 
    	return this ; 
    }
    
    public VehicleBuilder fueltype(String type)
    {
    	this.fueltype = type; 
    	return this ; 
    }
   
    public VehicleBuilder rskm(int rskm)
    {
    	this.rskm = rskm ; 
    	return this ; 
    }
    
    public VehicleBuilder avergae(float average)
    {
    	this.average = average ; 
    	return this ; 
    }
    
    public VehicleBuilder cost(int cost)
    {
    	this.cost = cost ; 
    	return this ; 
    }
    
    public VehicleBuilder iName(String name) { 
    	this.insuranceName = name ; 
    	return this ; 
    }
    
    public VehicleBuilder iCompany(String name) { 
    	this.icompanyName = name ; 
    	return this ; 
    }
    
    public VehicleBuilder iDateoi(String doi) { 
    	this.idateOfInsurance = doi ; 
    	return this ; 
    }
    
    public VehicleBuilder iDateoe(String doe) { 
    	this.idateOfExpiry = doe ; 
    	return this ; 
    }
    
    public VehicleBuilder vehicleType(String type)
    {
    	this.vehicleType = type ; 
    	return this ; 
    }
    
    public VehicleBuilder driver(String name)
    {
    	this.driverName = name ; 
    	return this ; 
    }

    public Vehicle build() { 
    	Vehicle v = new Vehicle(this) ; 
    	validateVehicleObject(v) ; 
    	return v ; 
    }

    private void validateVehicleObject(Vehicle vehicle) {
        //Do some basic validations to check 
        //if user object does not break any assumption of system
    }

}
