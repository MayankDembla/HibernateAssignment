package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Vehicle;

public interface VehicleDao {

	Vehicle getVehicleByName(String name) ; 
	
	List<Vehicle> getregisteredVehicle() ; 

}
