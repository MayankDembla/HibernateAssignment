package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Company;

public interface CompanyDao {

	Company getCompanyByName(String name) ; 
	
	List<Company> getregisteredCompanies() ; 
	
	boolean isaValidUser(String name , String password) ; 
	
}
