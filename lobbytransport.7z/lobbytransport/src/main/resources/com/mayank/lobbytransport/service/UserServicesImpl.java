package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.dao.CompanyDao;
import com.mayank.lobbytransport.dao.CompanyDaoImpl;
import com.mayank.lobbytransport.dao.PersistDao;
import com.mayank.lobbytransport.dao.PersistDaoImpl;
import com.mayank.lobbytransport.model.Company;

public class UserServicesImpl implements UserServices{

	private PersistDao pdao ;
	private CompanyDao cdao ; 
	
	public UserServicesImpl() {
		pdao = new PersistDaoImpl() ;
		cdao  = new CompanyDaoImpl() ; 
	}
	
	@Override
	public boolean isValidUser(String name, String password) {
		return cdao.isaValidUser(name, password);
	}

	@Override
	public void registerNewUser(Company company) {
		pdao.registerCompany(company);
	}
	
	
	
}
