package com.mayank.lobbytransport.model;

import javax.persistence.Embeddable;

@Embeddable
public class Insurance {
	
	private String insuranceName ; 
	
	private String companyName ; 
	
	private String fromDate ; 
	
	private String expiryDate ;
	
	public String getInsuranceName() {
		return insuranceName;
	}

	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	} 

}
