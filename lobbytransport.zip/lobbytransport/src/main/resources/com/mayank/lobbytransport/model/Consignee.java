package com.mayank.lobbytransport.model;

public class Consignee {

	private Company comapny;

	private Goods requestedGoods;

	public Company getUser() {
		return comapny;
	}

	public void setUser(Company user) {
		this.comapny = user;
	}

	public Goods getRequestedGoods() {
		return requestedGoods;
	}

	public void setRequestedGoods(Goods requestedGoods) {
		this.requestedGoods = requestedGoods;
	}

}
