package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Consignee;
import com.mayank.lobbytransport.util.HibernateUtil;

public class ConsigneeDaoImpl implements ConsigneeDao {

	private Session session;

	public ConsigneeDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
	}
	
	@Override
	public Consignee getConsigneebyName(String name) {
		Consignee consignee = null;

		Criteria criteria = session.createCriteria(Company.class);
		criteria.add(Restrictions.eq("name", name)); // Since Company Name is Unique

		List<Consignee> listuser = criteria.list();

		if (!listuser.isEmpty())
			consignee = listuser.get(0);

		return consignee;
	}

	@Override
	public List<Consignee> getRegisteredConsignee() {

		return session.createCriteria(Consignee.class).list();
	}

}
