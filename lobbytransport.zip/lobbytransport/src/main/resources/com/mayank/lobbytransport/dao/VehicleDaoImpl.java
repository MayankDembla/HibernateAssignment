package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import com.mayank.lobbytransport.model.Vehicle;
import com.mayank.lobbytransport.util.HibernateUtil;

public class VehicleDaoImpl implements VehicleDao{

	private Session session;
	private Criteria criteria ; 

	public VehicleDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		 criteria = session.createCriteria(Vehicle.class);
	}
	
	@Override
	public Vehicle getVehicleByName(String vno) {
	
		criteria.add(Restrictions.eq("vehicleNo", vno)); // Since Company Name is Unique

		if (!criteria.list().isEmpty())
			return  (Vehicle) criteria.list().get(0);

		return null;
	}

	@Override
	public List<Vehicle> getregisteredVehicle() {
		return session.createCriteria(Vehicle.class).list();
	}

}
