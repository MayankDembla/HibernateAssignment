package com.mayank.lobbytransport.model;

public class Consigner {
	
	private Company company ; 
	
    private Goods availablegoods ; 

    private Goods soldoutgoods ;

	public Company getUser() {
		return company;
	}

	public void setUser(Company company) {
		this.company = company;
	}

	public Goods getAvailablegoods() {
		return availablegoods;
	}

	public void setAvailablegoods(Goods availablegoods) {
		this.availablegoods = availablegoods;
	}

	public Goods getSoldoutgoods() {
		return soldoutgoods;
	}

	public void setSoldoutgoods(Goods soldoutgoods) {
		this.soldoutgoods = soldoutgoods;
	} 
    
    
}
