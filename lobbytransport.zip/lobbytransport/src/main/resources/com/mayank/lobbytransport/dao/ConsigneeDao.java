package com.mayank.lobbytransport.dao;

import java.util.List;

import com.mayank.lobbytransport.model.Consignee;

public interface ConsigneeDao {

	Consignee getConsigneebyName(String name) ; 
	
	List<Consignee> getRegisteredConsignee() ; 
	
}
