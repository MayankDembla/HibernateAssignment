package com.mayank.lobbytransport.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Driver {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int driverid ; 
	
	private Company user  ; 
	
	@OneToMany(mappedBy="driver")
	private List<Vehicle> vehicles ; 
	
	public Company getUser() {
		return user;
	}

	public void setUser(Company user) {
		this.user = user;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}
}
