package com.mayank.lobbytransport.model;

public class CompanyBuilder {

	protected int id ; 	
	protected final String name;
	protected final String password;
	protected String address;
	protected String city;
	protected String state;
	protected long mobileNumber;
	protected String email;
	
	public CompanyBuilder(String name, String password)
	{
		this.name = name ; 
		this.password = password ; 
	}
	
	public CompanyBuilder address(String address) 
	{
		this.address = address ; 
		return this ; 
	}
	
	public CompanyBuilder city(String city)
	{
		 this.city = city ; 
		 return this ; 
	}
	
	public CompanyBuilder state(String state)
	{
		this.state = state ; 
		return this ; 
	}
	
	public CompanyBuilder mobile(long mobile)
	{
		this.mobileNumber = mobile ; 
		return this ; 
	}
	
	public CompanyBuilder email(String email)
	{
		this.email = email ; 
		return this ; 
	}
	
	public Company build() {
		Company company = new Company(this) ; 
		validateUserObject(company) ; 
		return company ; 
	}
	
	public void validateUserObject(Company company) {
		 //Do some basic validations to check 
        //if user object does not break any assumption of system
	}
}
