package com.mayank.lobbytransport.service;

import com.mayank.lobbytransport.model.Company;

public interface UserServices {

	boolean isValidUser(String name, String password);

	void registerNewUser(Company company);
}
