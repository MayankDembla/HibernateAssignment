package com.mayank.lobbytransport.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.CompanyBuilder;
import com.mayank.lobbytransport.service.UserServices;
import com.mayank.lobbytransport.service.UserServicesImpl;

/**
 * Servlet implementation class ValidateUser
 */
@WebServlet("/validate-user")
public class ValidateUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static UserServices user ;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ValidateUserServlet() {
    	user = new UserServicesImpl() ; 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		String act = req.getParameter("ACT");
		
		HttpSession session = req.getSession();
		
		if(act.equals("doLog"))    // Login USer 
		{
			String userName = req.getParameter("Username") ; 
			
			if(user.isValidUser(userName, req.getParameter("Password"))) {
				session.setAttribute("u_name",userName);
				session.setAttribute("u_role", user.getRoleByName(userName));
				session.setAttribute("content_page","ucontent.jsp");
				res.sendRedirect("index.jsp");
			} else {
				session.setAttribute("content_page","uLogin.jsp");
				res.sendRedirect("index.jsp?msg=2");
			}
	    } else if(act.equals("doReg"))  // Register User 
	    {
	    	CompanyBuilder builder = new CompanyBuilder(req.getParameter("username"),req.getParameter("password"))
	    			                  .address(req.getParameter("address"))
	    	                          .city(req.getParameter("city"))
	    	                          .state(req.getParameter("state"))
	    	                          .mobile(Long.valueOf(req.getParameter("mbno")))
	    	                          .email( req.getParameter("email")) ; 
	    	                          
	    	switch(req.getParameter("role"))
	    	{
	    	case "company" : 
	    		  Company company =   builder.build() ; 
	    		  user.registerNewUser(company);
	    		break ; 
	    	case "driver" : 
	    		  
	    		break ;
	    	case "consigner" : 
	    		break ; 
	    	case "consignee" :
	    		break ; 
	    	}
	    	
	    	
	    	session.setAttribute("content_page","register.jsp");
	    	res.sendRedirect("index.jsp?msg=1");
	    }
		
		
	}



}
