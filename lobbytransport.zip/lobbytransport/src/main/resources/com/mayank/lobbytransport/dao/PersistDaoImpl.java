package com.mayank.lobbytransport.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Consignee;
import com.mayank.lobbytransport.model.Consigner;
import com.mayank.lobbytransport.model.Driver;
import com.mayank.lobbytransport.model.Vehicle;
import com.mayank.lobbytransport.util.HibernateUtil;

public class PersistDaoImpl implements PersistDao {

	private Transaction transaction;

	private Session session;

	public PersistDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		transaction = session.beginTransaction();
	}

	@Override
	public void registerCompany(Company company) {

		try {
			session.save(company);
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	@Override
	public void registerVehicle(Vehicle vehicle) {
		try {
			session.save(vehicle);
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	@Override
	public void registerDriver(Driver driver) {
		try {
			session.save(driver);
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

	}

	@Override
	public void registerConsignee(Consignee consignee) {
		try {
			session.save(consignee);
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

	}

	@Override
	public void registerConsignor(Consigner consignor) {
		try {
			session.save(consignor);
			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

	}

}
