package com.mayank.lobbytransport.dao;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Consignee;
import com.mayank.lobbytransport.model.Consigner;
import com.mayank.lobbytransport.model.Driver;
import com.mayank.lobbytransport.model.Vehicle;

public interface PersistDao {

	void registerCompany(Company company);
	
	void registerVehicle(Vehicle vehicle) ; 
	
	void registerDriver(Driver driver) ; 
	
	void registerConsignee(Consignee consignee) ; 
	
	void registerConsignor(Consigner consignor) ; 
	
}
