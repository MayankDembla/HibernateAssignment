package com.mayank.lobbytransport.service;

import java.util.List;

import com.mayank.lobbytransport.dao.DriverDao;
import com.mayank.lobbytransport.dao.DriverDaoImpl;
import com.mayank.lobbytransport.dao.PersistDao;
import com.mayank.lobbytransport.dao.PersistDaoImpl;
import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.model.Driver;

public class DriverServicesImpl implements DriverServices{

	private PersistDao dao; 
	private DriverDao ddao ; 
	
	public DriverServicesImpl() {
          dao = new PersistDaoImpl() ;
          ddao = new DriverDaoImpl() ; 
	}
	
	@Override
	public void registerDriver(Company company) {
	   Driver driver = new Driver() ; 
	   driver.setUser(company);
	   dao.registerDriver(driver);
	}

	@Override
	public Driver getDriverByName(String name) {
		return ddao.getDriverByName(name) ; 
	}

	@Override
	public List<Driver> getDrivers() {
		return ddao.getregisteredDrivers();
	}
	
}
