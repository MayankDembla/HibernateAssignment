package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mayank.lobbytransport.model.Company;
import com.mayank.lobbytransport.util.HibernateUtil;

public class CompanyDaoImpl implements CompanyDao {

	private Session session;
	
	private Criteria criteria ; 

	public CompanyDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
		criteria = session.createCriteria(Company.class);
	}
	
	@Override
	public Company getCompanyByName(String name)
	{
		Company company = null;
		criteria.add(Restrictions.eq("name", name)); // Since Company Name is Unique
		List<Company> listuser = criteria.list();

		if (!listuser.isEmpty())
			company = listuser.get(0);

		return company;
	}

	@Override
	public List<Company> getregisteredCompanies() {
		
		return criteria.list();
	}

	@Override
	public boolean isaValidUser(String name, String password) {
		
		criteria.add(Restrictions.eq("name", name));
		criteria.add(Restrictions.eq("password", password));
		
		if(criteria.list().get(0) == null)
			return false ; 
		
	   return true ; 
		
	}

}
