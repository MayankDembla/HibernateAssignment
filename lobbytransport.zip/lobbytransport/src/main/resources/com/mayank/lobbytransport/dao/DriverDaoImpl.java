package com.mayank.lobbytransport.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.mayank.lobbytransport.model.Driver;
import com.mayank.lobbytransport.util.HibernateUtil;

public class DriverDaoImpl implements DriverDao {

	private Session session;

	public DriverDaoImpl() {
		session = HibernateUtil.getSessionFactory().openSession();
	}

	@Override
	public Driver getDriverByName(String name) {
		Driver driver = null;

		Criteria criteria = session.createCriteria(Driver.class);
		criteria.add(Restrictions.eq("name", name)); // Since Company Name is Unique

		List<Driver> listdriver = criteria.list();

		if (!listdriver.isEmpty())
			driver = listdriver.get(0);

		return driver;
	}

	@Override
	public List<Driver> getregisteredDrivers() 
	{
		return session.createCriteria(Driver.class).list();
	}
}
