package com.dembla.countryportal.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dembla.countryportal.dao.PortalDao;
import com.dembla.countryportal.dao.PortalDaoImpl;
import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;

@WebServlet("/portal")
public class PortalController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private PortalDao dao;

	public PortalController() {
		dao = new PortalDaoImpl();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String role = (String) session.getAttribute("role");

		switch (Integer.parseInt(role)) {
		
		case 1: // Add Country

			Country c = new Country();
			c.setName(request.getParameter("country"));
			dao.persistData(c);
			break;
			
		case 2 : // Add Language 
			
			Language lang = new Language() ; 
			lang.setName(request.getParameter("language"));
			dao.persistData(lang);
			break;
			
		case 3: //	Add Capital
			
			City city = new City();
			city.setName(request.getParameter("capital"));
			dao.persistData(city);
			break; 
			
		case 4: // Add Sports name 
			
			Sports sport = new Sports() ; 
			sport.setName(request.getParameter("sports"));
			dao.persistData(sport);
			break ; 
			
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("add-country.jsp?msg=" + role);
		dispatcher.forward(request, response);
	}

}
