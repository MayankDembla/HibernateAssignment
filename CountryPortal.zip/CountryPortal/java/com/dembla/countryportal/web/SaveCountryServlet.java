package com.dembla.countryportal.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dembla.countryportal.dao.PortalDao;
import com.dembla.countryportal.dao.PortalDaoImpl;
import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;

@WebServlet("/scs")
public class SaveCountryServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private PortalDao  dao; 
	
	public SaveCountryServlet() {
		dao = new PortalDaoImpl() ; 
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String country = request.getParameter("country") ; 
		String language = request.getParameter("language") ; 
		String capital = request.getParameter("capital") ; 
		String sports = request.getParameter("sports") ;
		
		Country cou = new Country() ; 
		cou.setName(country);
		
		// add Sports
		Sports spo = new Sports() ; 
		spo.setName(sports); 
		spo.getCountries().add(cou) ; 
		cou.getSports().add(spo) ; 
		
		// add capital
		City city = new City() ; 
		city.setName(capital);
		city.setCountry(cou);
		cou.setCapital(city);
		
		//add language
		Language lang = new Language() ;
		lang.setName(language);
		lang.getCountry().add(cou) ; 
		cou.setLang(lang);
		
		
		dao.persistData(cou, lang, city, spo);
	}
}
