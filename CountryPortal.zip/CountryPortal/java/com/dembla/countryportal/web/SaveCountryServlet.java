package com.dembla.countryportal.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dembla.countryportal.dao.EntityDao;
import com.dembla.countryportal.dao.EntityDaoImpl;
import com.dembla.countryportal.dao.PortalDao;
import com.dembla.countryportal.dao.PortalDaoImpl;
import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;

@WebServlet("/scs")
public class SaveCountryServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private PortalDao dao;

	private EntityDao entity;

	public SaveCountryServlet() {
		dao = new PortalDaoImpl();
		entity = new EntityDaoImpl();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Country cou = entity.getCountryByName(request.getParameter("country"));

		// add Sports
		Sports spo = entity.getSportsByName(request.getParameter("sports"));
		spo.getCountries().add(cou);
		cou.getSports().add(spo);

		// add capital
		City city = entity.getCityByName(request.getParameter("capital"));

		try {
			if (city.getCountry().getName() == null || city.getCountry().getName().equals(cou.getName())) {
				city.setCountry(cou);
				cou.setCapital(city);
			} else // City Already patched to Some Country
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("add-country.jsp?msg=6");
				dispatcher.forward(request, response);
				return ; 
			}
		} catch (NullPointerException exp) {
			city.setCountry(cou);
			cou.setCapital(city);
		}

		// add language
		Language lang = entity.getLanguageByName(request.getParameter("language"));
		lang.getCountry().add(cou);
		cou.setLang(lang);

		dao.persistData(cou, lang, city, spo);

		RequestDispatcher dispatcher = request.getRequestDispatcher("add-country.jsp?msg=5");
		dispatcher.forward(request, response);
	}
}
