package com.dembla.countryportal.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dembla.countryportal.dao.EntityDao;
import com.dembla.countryportal.dao.EntityDaoImpl;

@WebServlet("/relation")
public class RelationController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	EntityDao dao ; 
	
	public RelationController() {
		dao = new EntityDaoImpl() ; 
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		List<String> country =  dao.getregCountris();
		List<String> language = dao.getregLanguage() ; 
		List<String> capital = dao.getregCapital() ; 
		List<String> sports = dao.getregSports() ; 
		
		
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/country-info.jsp");
		
		request.setAttribute("country", country);
		request.setAttribute("language", language);
		request.setAttribute("capital", capital);
		request.setAttribute("sports", sports);
		
		rd.forward(request, response);
	}

}
