package com.dembla.countryportal.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Language {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int langid ; 
	
	private String name ;
	
	// One Language can be Spoken By Differnt Countries 
	
	@OneToMany(mappedBy="lang")
	List<Country> country = new ArrayList<>() ; 
	

	public int getLangid() {
		return langid;
	}

	public List<Country> getCountry() {
		return country;
	}

	public void setCountry(List<Country> country) {
		this.country = country;
	}

	public void setLangid(int langid) {
		this.langid = langid;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Language [langid=" + langid + ", name=" + name + "]";
	}

	public void setName(String name) {
		this.name = name;
	} 
}
