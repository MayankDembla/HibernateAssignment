package com.dembla.countryportal.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Sports {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int sportsid;

	@Column(unique = true)
	private String name;
	
	// ## A Sport can be played by mulitple Countires ## //
	@ManyToMany(mappedBy="sports")
	List<Country> countries = new ArrayList<>() ; 
	
	public int getSportsid() {
		return sportsid;
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public void setSportsid(int sportsid) {
		this.sportsid = sportsid;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Sports [sportsid=" + sportsid + ", name=" + name + "]";
	}

	public void setName(String name) {
		this.name = name;
	}

}
