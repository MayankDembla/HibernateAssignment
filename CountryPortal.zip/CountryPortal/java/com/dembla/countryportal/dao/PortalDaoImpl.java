package com.dembla.countryportal.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;
import com.dembla.countryportal.util.HibernateUtil;

public class PortalDaoImpl implements PortalDao {

	private Transaction transaction;
	

	@Override
	public void persistData(Country country) {

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			session.save(country);

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	@Override
	public void persistData(Language language) {

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			session.save(language);

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	@Override
	public void persistData(City city) {
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			session.save(city);

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	@Override
	public void persistData(Sports sports) {
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			session.save(sports);

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	@Override
	public void persistData(Country country, Language lang, City capital, Sports sports) {

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			session.merge(lang);
			session.merge(capital);
			session.merge(sports);
			session.merge(country);

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

	}

}
