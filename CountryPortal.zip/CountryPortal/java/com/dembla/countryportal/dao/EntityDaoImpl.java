package com.dembla.countryportal.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;
import com.dembla.countryportal.util.HibernateUtil;

public class EntityDaoImpl implements EntityDao {

	private Transaction transaction;

	@Override
	public List<String> getregCountris() {

		List<String> ls = null;

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			Query q = session.createQuery("Select c.name from Country c");

			ls = q.list();

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

		return ls;
	}

	@Override
	public List<String> getregLanguage() {

		List<String> ls = null;

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			Query q = session.createQuery("Select l.name from Language l");

			ls = q.list();

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

		return ls;
	}

	@Override
	public List<String> getregCapital() {

		List<String> ls = null;

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			Query q = session.createQuery("Select c.name from City c");

			ls = q.list();

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

		return ls;
	}

	@Override
	public List<String> getregSports() {

		List<String> ls = null;

		try {
			Session session = HibernateUtil.getSessionFactory().openSession();

			transaction = session.beginTransaction();

			Query q = session.createQuery("Select s.name from Sports s");

			ls = q.list();

			transaction.commit();

		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}

		return ls;
	}

}
