package com.dembla.countryportal.dao;

import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;

public interface PortalDao {
	
	void persistData(Country country) ; 
	
	void persistData(Language language) ; 
	
	void persistData(City city) ; 
	
	void persistData(Sports sports) ; 
	
	void persistData(Country country, Language lang, City capital, Sports sports) ;
	
}
