package com.dembla.countryportal.dao;

import java.util.List;

import com.dembla.countryportal.model.City;
import com.dembla.countryportal.model.Country;
import com.dembla.countryportal.model.Language;
import com.dembla.countryportal.model.Sports;

public interface EntityDao {


	// List to Show in UI //
	List<String> getregCountris();

	List<String> getregLanguage();

	List<String> getregCapital();

	List<String> getregSports();

	List<Country> getCountry();
	
	// Object to get the previous Data Stored // 

	Country getCountryByName(String name);

	Sports getSportsByName(String name);

	City getCityByName(String name);

	Language getLanguageByName(String name);

}
