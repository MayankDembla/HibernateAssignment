package com.dembla.countryportal.dao;

import java.util.List;

public interface EntityDao {
	
	List<String> getregCountris() ; 
	
	List<String> getregLanguage() ; 
	
	List<String> getregCapital() ; 
	
	List<String> getregSports() ; 

}
